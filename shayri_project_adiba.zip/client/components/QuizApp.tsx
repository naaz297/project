import { useState, useEffect } from "react";
import { quizQuestions, QuizQuestion } from "../data/quizData";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";

export default function QuizApp() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [isQuizComplete, setIsQuizComplete] = useState(false);

  const question = quizQuestions[currentQuestion];

  const handleAnswerClick = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
    
    if (answerIndex === question.correctAnswer) {
      setScore(score + 1);
      alert("ب��ت بہترین! آپ نے صحیح جواب دیا ہے۔\n(Excellent! You have chosen the right answer)");
    } else {
      alert("آپ کا جواب غلط ہے، براہ کرم دوبارہ کوشش کریں۔\n(Your answer is wrong, please try again)");
    }
    
    setShowResult(true);
  };

  const handleNextQuestion = () => {
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setIsQuizComplete(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setScore(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setIsQuizComplete(false);
  };

  const getScoreMessage = () => {
    const percentage = (score / quizQuestions.length) * 100;
    if (percentage >= 80) return "عمدہ! آپ اردو شاعری کے ماہر ہیں!";
    if (percentage >= 60) return "اچھا! آپ کو اردو شاعری کا اچھا علم ہے۔";
    if (percentage >= 40) return "ٹھیک ہے! مزید پڑھیے اور سیکھیے۔";
    return "کوشش جاری رکھیے! اردو شاعری کا مطالعہ کریں۔";
  };

  if (isQuizComplete) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-cover bg-center bg-no-repeat relative"
           style={{
             backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://images.pexels.com/photos/7951839/pexels-photo-7951839.jpeg')`
           }}>
        <Card className="w-full max-w-2xl bg-white/95 backdrop-blur-sm border-2 border-amber-200 shadow-2xl">
          <CardHeader className="text-center bg-gradient-to-r from-amber-50 to-orange-50 rounded-t-lg">
            <CardTitle className="text-3xl font-bold text-amber-800 mb-2">
              🏆 کوئز مکمل ہوا!
            </CardTitle>
            <p className="text-lg text-amber-700">Quiz Complete!</p>
          </CardHeader>
          <CardContent className="p-8 text-center">
            <div className="mb-6">
              <div className="text-6xl font-bold text-amber-600 mb-2">
                {score}/{quizQuestions.length}
              </div>
              <p className="text-xl text-gray-700 mb-4">{getScoreMessage()}</p>
              <Badge variant="secondary" className="text-lg px-4 py-2">
                {Math.round((score / quizQuestions.length) * 100)}% اسکور
              </Badge>
            </div>
            <Button 
              onClick={resetQuiz}
              className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white px-8 py-3 text-lg font-semibold rounded-lg shadow-lg transition-all duration-300 transform hover:scale-105"
            >
              🔄 دوبارہ کھیلیں (Play Again)
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-cover bg-center bg-no-repeat relative"
         style={{
           backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://images.pexels.com/photos/7951839/pexels-photo-7951839.jpeg')`
         }}>
      
      {/* Quiz Header */}
      <div className="absolute top-4 left-4 right-4 flex justify-between items-center">
        <Badge variant="outline" className="bg-white/90 text-gray-800 px-4 py-2 text-lg font-semibold">
          سوال {currentQuestion + 1} از {quizQuestions.length}
        </Badge>
        <Badge variant="outline" className="bg-white/90 text-gray-800 px-4 py-2 text-lg font-semibold">
          اسکور: {score}
        </Badge>
      </div>

      <Card className="w-full max-w-4xl bg-white/95 backdrop-blur-sm border-2 border-amber-200 shadow-2xl">
        <CardHeader className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-t-lg">
          <CardTitle className="text-2xl font-bold text-center text-amber-800 mb-4">
            🌟 اردو شاعری کوئز
          </CardTitle>
          <p className="text-center text-amber-700 text-lg font-medium">
            Urdu Poetry Quiz - یہ شعر کس شاعر کا ہے؟
          </p>
        </CardHeader>
        
        <CardContent className="p-8">
          {/* Poetry Display */}
          <div className="mb-8 p-6 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg border-l-4 border-amber-500 shadow-inner">
            <div className="text-center mb-4">
              <h3 className="text-2xl font-bold text-gray-800 leading-loose" style={{ fontFamily: 'serif' }}>
                {question.shayari.split('\n').map((line, index) => (
                  <div key={index} className="mb-2">{line}</div>
                ))}
              </h3>
              <p className="text-gray-600 italic mt-4 text-lg">
                {question.shayariEnglish.split('\n').map((line, index) => (
                  <div key={index} className="mb-1">{line}</div>
                ))}
              </p>
            </div>
          </div>

          {/* Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            {question.options.map((option, index) => (
              <Button
                key={index}
                onClick={() => !showResult && handleAnswerClick(index)}
                disabled={showResult}
                variant={
                  showResult
                    ? index === question.correctAnswer
                      ? "default"
                      : selectedAnswer === index
                      ? "destructive"
                      : "outline"
                    : "outline"
                }
                className={`p-6 text-xl font-semibold h-auto transition-all duration-300 transform hover:scale-105 ${
                  showResult
                    ? index === question.correctAnswer
                      ? "bg-green-500 hover:bg-green-600 text-white border-green-500"
                      : selectedAnswer === index
                      ? "bg-red-500 hover:bg-red-600 text-white border-red-500"
                      : "bg-gray-100 text-gray-400 border-gray-300"
                    : "bg-white hover:bg-amber-50 text-gray-800 border-amber-300 hover:border-amber-500"
                }`}
              >
                <span className="text-2xl mr-3">
                  {String.fromCharCode(65 + index)}.
                </span>
                {option}
              </Button>
            ))}
          </div>

          {/* Next Button */}
          {showResult && (
            <div className="text-center">
              <div className="mb-4 p-4 bg-amber-50 rounded-lg border border-amber-200">
                <p className="text-lg font-semibold text-amber-800">
                  صحیح جواب: <span className="font-bold">{question.poet}</span>
                </p>
              </div>
              <Button
                onClick={handleNextQuestion}
                className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white px-8 py-3 text-lg font-semibold rounded-lg shadow-lg transition-all duration-300 transform hover:scale-105"
              >
                {currentQuestion < quizQuestions.length - 1 ? "اگلا سوال ←" : "نتائج دیکھیں 🏆"}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

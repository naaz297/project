import QuizApp from "../components/QuizApp";

export default function Index() {
  return <QuizApp />;
}

export interface QuizQuestion {
  id: number;
  shayari: string;
  shayariEnglish: string;
  options: string[];
  correctAnswer: number;
  poet: string;
}

export const quizQuestions: QuizQuestion[] = [
  {
    id: 1,
    shayari: "محبت میں نہیں ہے فرق جینے اور مرنے کا\nاسی کو دیکھ کر جیتے ہیں جس کے لیے مرتے ہیں",
    shayariEnglish: "Mohabbat mein nahin hai faraq jeene aur marne ka\nUsi ko dekh kar jeete hain jis ke liye marte hain",
    options: ["احمد فراز", "علامہ اقبال", "میر تقی میر", "غالب"],
    correctAnswer: 0,
    poet: "احمد فراز"
  },
  {
    id: 2,
    shayari: "دل سے نکلتے ہیں جو لفظ اثر رکھتے ہیں\nپر نہیں طاقت پرواز میں اکثر لفظوں میں",
    shayariEnglish: "Dil se niklte hain jo lafz asar rakhte hain\nPar nahin taqat-e-parwaaz mein aksar lafzon mein",
    options: ["فیض احمد فیض", "احمد فراز", "علامہ اقبال", "میر تقی میر"],
    correctAnswer: 2,
    poet: "علامہ اقبال"
  },
  {
    id: 3,
    shayari: "ہزاروں خواہشیں ایسی کہ ہر خواہش پہ دم نکلے\nبہت نکلے میرے ارمان لیکن پھر بھی کم نکلے",
    shayariEnglish: "Hazaron khwahishen aisi ke har khwahish pe dam nikle\nBahut nikle mere armaan lekin phir bhi kam nikle",
    options: ["میر تقی میر", "غالب", "اکبر الہ آبادی", "داغ دہلوی"],
    correctAnswer: 1,
    poet: "غالب"
  },
  {
    id: 4,
    shayari: "مجھ سے پہلی سی محبت میرے محبوب نہ مانگ\nمیں نے سمجھا تھا کہ تو ہے تو درخشاں ہے حیات",
    shayariEnglish: "Mujh se pehli si mohabbat mere mehboob na maang\nMein ne samjha tha ke tu hai to drakhshan hai hayaat",
    options: ["فیض احمد فیض", "احمد فراز", "جوش ملیح آبادی", "ناصر کاظمی"],
    correctAnswer: 0,
    poet: "فیض احمد فیض"
  },
  {
    id: 5,
    shayari: "کوئی دیوانہ کہتا ہے کوئی پاگل صدا دیتا ہے\nمیری دنیا میں تجھ کو سب سے اچھا میں کہتا ہوں",
    shayariEnglish: "Koi deewana kehta hai koi paagal sada deta hai\nMeri duniya mein tujh ko sab se achha main kehta hun",
    options: ["احمد فراز", "پروین شاکر", "جون ایلیا", "ناصر کاظمی"],
    correctAnswer: 0,
    poet: "احمد فراز"
  }
];
